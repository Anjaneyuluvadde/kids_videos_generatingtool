import streamlit as st
import os
from modules.renderer import render_video

st.set_page_config(page_title="Kid Video Generator", page_icon="🎨", layout="wide")

st.title("🎨 AI-Powered Kid Video Generator")
st.markdown("Create colorful, beat-synced videos for kids with auto-captions and effects! No API keys needed.")

with st.sidebar:
    st.header("Settings")
    template = st.selectbox("Select Template", ["ABC Learning", "Animal Story", "Kids Rhymes", "Motivation", "Cartoon Slideshow"])
    resolution = st.selectbox("Resolution", ["1080x1920 (Shorts/TikTok)", "1920x1080 (Landscape)"])
    st.markdown("---")
    st.markdown("### Instructions")
    st.markdown("1. Upload assets (images, video, music)")
    st.markdown("2. Select a template")
    st.markdown("3. Click Generate")

st.header("Upload Assets")
col1, col2 = st.columns(2)
with col1:
    uploaded_images = st.file_uploader("Upload Images/Videos", accept_multiple_files=True, type=['png', 'jpg', 'jpeg', 'mp4'])
with col2:
    uploaded_music = st.file_uploader("Upload Background Music", type=['mp3', 'wav'])

st.header("Subtitle Generation")
use_whisper = st.checkbox("Generate subtitles locally using Whisper AI", value=True)
st.info("Whisper runs 100% locally on your machine for subtitle generation.")

if st.button("🚀 Generate Video", use_container_width=True, type="primary"):
    if not uploaded_images or not uploaded_music:
        st.error("Please upload both visuals and music to proceed.")
    else:
        with st.status("Processing Video...", expanded=True) as status:
            st.write("Detecting scenes...")
            st.write("Syncing with music beat...")
            st.write("Generating captions...")
            st.write("Applying effects & rendering...")
            
            try:
                output_path = render_video(uploaded_images, uploaded_music, template, resolution, use_whisper)
                status.update(label="Render Complete!", state="complete", expanded=False)
                st.success(f"Video saved to: {output_path}")
                
                with open(output_path, "rb") as file:
                    st.download_button(
                        label="⬇️ Download Generated Video",
                        data=file,
                        file_name="generated_kids_video.mp4",
                        mime="video/mp4"
                    )
            except Exception as e:
                status.update(label="Error generating video", state="error", expanded=True)
                st.error(f"Error: {str(e)}")
